﻿namespace PAV1_AO_2018
{
    partial class frmHistorialMedico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCargarOdontologo = new System.Windows.Forms.Button();
            this.btnCargarPaciente = new System.Windows.Forms.Button();
            this.dtpfechaHistorial = new System.Windows.Forms.DateTimePicker();
            this.txtApellidoPaciente = new System.Windows.Forms.TextBox();
            this.btnBuscarOdontologos = new System.Windows.Forms.Button();
            this.btnBuscarPacientes = new System.Windows.Forms.Button();
            this.txtNombrePaciente = new System.Windows.Forms.TextBox();
            this.txtOdontologo = new System.Windows.Forms.TextBox();
            this.txtIdPaciente = new System.Windows.Forms.TextBox();
            this.txtIdOdontologo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvDetalle = new System.Windows.Forms.DataGridView();
            this.col_id_elemento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_id_prestacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_id_cara = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_importe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_id_historial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_id_detalle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn23 = new System.Windows.Forms.Button();
            this.btn24 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.btn26 = new System.Windows.Forms.Button();
            this.btn27 = new System.Windows.Forms.Button();
            this.btn28 = new System.Windows.Forms.Button();
            this.btn41 = new System.Windows.Forms.Button();
            this.btn42 = new System.Windows.Forms.Button();
            this.btn43 = new System.Windows.Forms.Button();
            this.btn45 = new System.Windows.Forms.Button();
            this.btn46 = new System.Windows.Forms.Button();
            this.btn47 = new System.Windows.Forms.Button();
            this.btn48 = new System.Windows.Forms.Button();
            this.btn31 = new System.Windows.Forms.Button();
            this.btn32 = new System.Windows.Forms.Button();
            this.btn33 = new System.Windows.Forms.Button();
            this.btn34 = new System.Windows.Forms.Button();
            this.btn35 = new System.Windows.Forms.Button();
            this.btn38 = new System.Windows.Forms.Button();
            this.btn36 = new System.Windows.Forms.Button();
            this.btn37 = new System.Windows.Forms.Button();
            this.btn51 = new System.Windows.Forms.Button();
            this.btn52 = new System.Windows.Forms.Button();
            this.btn53 = new System.Windows.Forms.Button();
            this.btn54 = new System.Windows.Forms.Button();
            this.btn55 = new System.Windows.Forms.Button();
            this.btn81 = new System.Windows.Forms.Button();
            this.btn65 = new System.Windows.Forms.Button();
            this.btn61 = new System.Windows.Forms.Button();
            this.btn62 = new System.Windows.Forms.Button();
            this.btn64 = new System.Windows.Forms.Button();
            this.btn63 = new System.Windows.Forms.Button();
            this.btn84 = new System.Windows.Forms.Button();
            this.btn83 = new System.Windows.Forms.Button();
            this.btn82 = new System.Windows.Forms.Button();
            this.btn73 = new System.Windows.Forms.Button();
            this.btn72 = new System.Windows.Forms.Button();
            this.btn71 = new System.Windows.Forms.Button();
            this.btn85 = new System.Windows.Forms.Button();
            this.btn74 = new System.Windows.Forms.Button();
            this.btn75 = new System.Windows.Forms.Button();
            this.btnGrabar = new System.Windows.Forms.Button();
            this.txtOdontograma = new System.Windows.Forms.TextBox();
            this.groupBoxElemento = new System.Windows.Forms.GroupBox();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.cmbPrestacion = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbCara = new System.Windows.Forms.ComboBox();
            this.lblcara = new System.Windows.Forms.Label();
            this.txtNroElemento = new System.Windows.Forms.TextBox();
            this.lblElemento = new System.Windows.Forms.Label();
            this.btn44 = new System.Windows.Forms.Button();
            this.btnQuitar = new System.Windows.Forms.Button();
            this.dgvHistorial = new System.Windows.Forms.DataGridView();
            this.col_fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_idHistorial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_idPrestacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_idelemento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_idcara = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDescripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colimporte = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).BeginInit();
            this.groupBoxElemento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorial)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.groupBox1.Controls.Add(this.btnCargarOdontologo);
            this.groupBox1.Controls.Add(this.btnCargarPaciente);
            this.groupBox1.Controls.Add(this.dtpfechaHistorial);
            this.groupBox1.Controls.Add(this.txtApellidoPaciente);
            this.groupBox1.Controls.Add(this.btnBuscarOdontologos);
            this.groupBox1.Controls.Add(this.btnBuscarPacientes);
            this.groupBox1.Controls.Add(this.txtNombrePaciente);
            this.groupBox1.Controls.Add(this.txtOdontologo);
            this.groupBox1.Controls.Add(this.txtIdPaciente);
            this.groupBox1.Controls.Add(this.txtIdOdontologo);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(135, 8);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(631, 84);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // btnCargarOdontologo
            // 
            this.btnCargarOdontologo.Location = new System.Drawing.Point(155, 34);
            this.btnCargarOdontologo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCargarOdontologo.Name = "btnCargarOdontologo";
            this.btnCargarOdontologo.Size = new System.Drawing.Size(51, 25);
            this.btnCargarOdontologo.TabIndex = 22;
            this.btnCargarOdontologo.Text = "Cargar";
            this.btnCargarOdontologo.UseVisualStyleBackColor = true;
            this.btnCargarOdontologo.Click += new System.EventHandler(this.btnCargarOdontologo_Click);
            // 
            // btnCargarPaciente
            // 
            this.btnCargarPaciente.Location = new System.Drawing.Point(155, 9);
            this.btnCargarPaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCargarPaciente.Name = "btnCargarPaciente";
            this.btnCargarPaciente.Size = new System.Drawing.Size(51, 25);
            this.btnCargarPaciente.TabIndex = 21;
            this.btnCargarPaciente.Text = "Cargar";
            this.btnCargarPaciente.UseVisualStyleBackColor = true;
            this.btnCargarPaciente.Click += new System.EventHandler(this.btnCargarPaciente_Click);
            // 
            // dtpfechaHistorial
            // 
            this.dtpfechaHistorial.CustomFormat = "yyyy-MM-dd";
            this.dtpfechaHistorial.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpfechaHistorial.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfechaHistorial.Location = new System.Drawing.Point(96, 60);
            this.dtpfechaHistorial.Name = "dtpfechaHistorial";
            this.dtpfechaHistorial.Size = new System.Drawing.Size(103, 20);
            this.dtpfechaHistorial.TabIndex = 20;
            // 
            // txtApellidoPaciente
            // 
            this.txtApellidoPaciente.Location = new System.Drawing.Point(374, 11);
            this.txtApellidoPaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtApellidoPaciente.Name = "txtApellidoPaciente";
            this.txtApellidoPaciente.Size = new System.Drawing.Size(149, 20);
            this.txtApellidoPaciente.TabIndex = 13;
            // 
            // btnBuscarOdontologos
            // 
            this.btnBuscarOdontologos.Location = new System.Drawing.Point(541, 36);
            this.btnBuscarOdontologos.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBuscarOdontologos.Name = "btnBuscarOdontologos";
            this.btnBuscarOdontologos.Size = new System.Drawing.Size(51, 24);
            this.btnBuscarOdontologos.TabIndex = 11;
            this.btnBuscarOdontologos.Text = "Buscar";
            this.btnBuscarOdontologos.UseVisualStyleBackColor = true;
            this.btnBuscarOdontologos.Click += new System.EventHandler(this.btnBuscarOdontologos_Click);
            // 
            // btnBuscarPacientes
            // 
            this.btnBuscarPacientes.Location = new System.Drawing.Point(541, 7);
            this.btnBuscarPacientes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnBuscarPacientes.Name = "btnBuscarPacientes";
            this.btnBuscarPacientes.Size = new System.Drawing.Size(51, 25);
            this.btnBuscarPacientes.TabIndex = 10;
            this.btnBuscarPacientes.Text = "Buscar";
            this.btnBuscarPacientes.UseVisualStyleBackColor = true;
            this.btnBuscarPacientes.Click += new System.EventHandler(this.btnBuscarPacientes_Click);
            // 
            // txtNombrePaciente
            // 
            this.txtNombrePaciente.Location = new System.Drawing.Point(215, 11);
            this.txtNombrePaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNombrePaciente.Name = "txtNombrePaciente";
            this.txtNombrePaciente.Size = new System.Drawing.Size(149, 20);
            this.txtNombrePaciente.TabIndex = 9;
            this.txtNombrePaciente.TextChanged += new System.EventHandler(this.txtNombrePaciente_TextChanged);
            // 
            // txtOdontologo
            // 
            this.txtOdontologo.Location = new System.Drawing.Point(215, 39);
            this.txtOdontologo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtOdontologo.Name = "txtOdontologo";
            this.txtOdontologo.Size = new System.Drawing.Size(309, 20);
            this.txtOdontologo.TabIndex = 8;
            // 
            // txtIdPaciente
            // 
            this.txtIdPaciente.Location = new System.Drawing.Point(103, 13);
            this.txtIdPaciente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIdPaciente.Name = "txtIdPaciente";
            this.txtIdPaciente.Size = new System.Drawing.Size(49, 20);
            this.txtIdPaciente.TabIndex = 7;
            // 
            // txtIdOdontologo
            // 
            this.txtIdOdontologo.Location = new System.Drawing.Point(103, 38);
            this.txtIdOdontologo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIdOdontologo.Name = "txtIdOdontologo";
            this.txtIdOdontologo.Size = new System.Drawing.Size(49, 20);
            this.txtIdOdontologo.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 61);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fecha";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 39);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Odontologo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Paciente";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(28, 350);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Odontograma";
            // 
            // dgvDetalle
            // 
            this.dgvDetalle.AllowUserToAddRows = false;
            this.dgvDetalle.AllowUserToDeleteRows = false;
            this.dgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalle.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_id_elemento,
            this.col_id_prestacion,
            this.col_id_cara,
            this.col_importe,
            this.col_descripcion,
            this.col_id_historial,
            this.col_id_detalle});
            this.dgvDetalle.Location = new System.Drawing.Point(163, 208);
            this.dgvDetalle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvDetalle.Name = "dgvDetalle";
            this.dgvDetalle.ReadOnly = true;
            this.dgvDetalle.RowTemplate.Height = 28;
            this.dgvDetalle.Size = new System.Drawing.Size(577, 109);
            this.dgvDetalle.TabIndex = 5;
            this.dgvDetalle.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDetalle_RowEnter);
            // 
            // col_id_elemento
            // 
            this.col_id_elemento.HeaderText = "Elemento";
            this.col_id_elemento.Name = "col_id_elemento";
            this.col_id_elemento.ReadOnly = true;
            // 
            // col_id_prestacion
            // 
            this.col_id_prestacion.HeaderText = "Prestacion";
            this.col_id_prestacion.Name = "col_id_prestacion";
            this.col_id_prestacion.ReadOnly = true;
            // 
            // col_id_cara
            // 
            this.col_id_cara.HeaderText = "Cara";
            this.col_id_cara.Name = "col_id_cara";
            this.col_id_cara.ReadOnly = true;
            // 
            // col_importe
            // 
            this.col_importe.HeaderText = "Importe";
            this.col_importe.Name = "col_importe";
            this.col_importe.ReadOnly = true;
            // 
            // col_descripcion
            // 
            this.col_descripcion.HeaderText = "Descripcion";
            this.col_descripcion.Name = "col_descripcion";
            this.col_descripcion.ReadOnly = true;
            // 
            // col_id_historial
            // 
            this.col_id_historial.HeaderText = "id historial";
            this.col_id_historial.Name = "col_id_historial";
            this.col_id_historial.ReadOnly = true;
            this.col_id_historial.Visible = false;
            // 
            // col_id_detalle
            // 
            this.col_id_detalle.HeaderText = "id detalle";
            this.col_id_detalle.Name = "col_id_detalle";
            this.col_id_detalle.ReadOnly = true;
            this.col_id_detalle.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(559, 324);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Importe Total  $";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(661, 323);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(81, 20);
            this.txtTotal.TabIndex = 13;
            // 
            // btn11
            // 
            this.btn11.Location = new System.Drawing.Point(265, 382);
            this.btn11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(30, 27);
            this.btn11.TabIndex = 14;
            this.btn11.Text = "11";
            this.btn11.UseVisualStyleBackColor = true;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn12
            // 
            this.btn12.Location = new System.Drawing.Point(231, 382);
            this.btn12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(30, 27);
            this.btn12.TabIndex = 15;
            this.btn12.Text = "12";
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn13
            // 
            this.btn13.Location = new System.Drawing.Point(197, 382);
            this.btn13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(30, 27);
            this.btn13.TabIndex = 16;
            this.btn13.Text = "13";
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Click += new System.EventHandler(this.btn13_Click);
            // 
            // btn14
            // 
            this.btn14.Location = new System.Drawing.Point(163, 382);
            this.btn14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(30, 27);
            this.btn14.TabIndex = 17;
            this.btn14.Text = "14";
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Click += new System.EventHandler(this.btn14_Click);
            // 
            // btn15
            // 
            this.btn15.Location = new System.Drawing.Point(129, 382);
            this.btn15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(30, 27);
            this.btn15.TabIndex = 18;
            this.btn15.Text = "15";
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Click += new System.EventHandler(this.btn15_Click);
            // 
            // btn16
            // 
            this.btn16.Location = new System.Drawing.Point(95, 382);
            this.btn16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(30, 27);
            this.btn16.TabIndex = 19;
            this.btn16.Text = "16";
            this.btn16.UseVisualStyleBackColor = true;
            this.btn16.Click += new System.EventHandler(this.btn16_Click);
            // 
            // btn17
            // 
            this.btn17.Location = new System.Drawing.Point(61, 382);
            this.btn17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(30, 27);
            this.btn17.TabIndex = 20;
            this.btn17.Text = "17";
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Click += new System.EventHandler(this.btn17_Click);
            // 
            // btn18
            // 
            this.btn18.Location = new System.Drawing.Point(27, 382);
            this.btn18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(30, 27);
            this.btn18.TabIndex = 21;
            this.btn18.Text = "18";
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Click += new System.EventHandler(this.btn18_Click);
            // 
            // btn21
            // 
            this.btn21.Location = new System.Drawing.Point(583, 375);
            this.btn21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(30, 27);
            this.btn21.TabIndex = 22;
            this.btn21.Text = "21";
            this.btn21.UseVisualStyleBackColor = true;
            this.btn21.Click += new System.EventHandler(this.btn21_Click);
            // 
            // btn22
            // 
            this.btn22.Location = new System.Drawing.Point(617, 375);
            this.btn22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(30, 27);
            this.btn22.TabIndex = 23;
            this.btn22.Text = "22";
            this.btn22.UseVisualStyleBackColor = true;
            this.btn22.Click += new System.EventHandler(this.btn22_Click);
            // 
            // btn23
            // 
            this.btn23.Location = new System.Drawing.Point(651, 375);
            this.btn23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(30, 27);
            this.btn23.TabIndex = 24;
            this.btn23.Text = "23";
            this.btn23.UseVisualStyleBackColor = true;
            this.btn23.Click += new System.EventHandler(this.btn23_Click);
            // 
            // btn24
            // 
            this.btn24.Location = new System.Drawing.Point(685, 375);
            this.btn24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(30, 27);
            this.btn24.TabIndex = 25;
            this.btn24.Text = "24";
            this.btn24.UseVisualStyleBackColor = true;
            this.btn24.Click += new System.EventHandler(this.btn24_Click);
            // 
            // btn25
            // 
            this.btn25.Location = new System.Drawing.Point(719, 375);
            this.btn25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(30, 27);
            this.btn25.TabIndex = 26;
            this.btn25.Text = "25";
            this.btn25.UseVisualStyleBackColor = true;
            this.btn25.Click += new System.EventHandler(this.button12_Click);
            // 
            // btn26
            // 
            this.btn26.Location = new System.Drawing.Point(753, 375);
            this.btn26.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn26.Name = "btn26";
            this.btn26.Size = new System.Drawing.Size(30, 27);
            this.btn26.TabIndex = 27;
            this.btn26.Text = "26";
            this.btn26.UseVisualStyleBackColor = true;
            this.btn26.Click += new System.EventHandler(this.btn26_Click);
            // 
            // btn27
            // 
            this.btn27.Location = new System.Drawing.Point(787, 375);
            this.btn27.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn27.Name = "btn27";
            this.btn27.Size = new System.Drawing.Size(30, 27);
            this.btn27.TabIndex = 28;
            this.btn27.Text = "27";
            this.btn27.UseVisualStyleBackColor = true;
            this.btn27.Click += new System.EventHandler(this.btn27_Click);
            // 
            // btn28
            // 
            this.btn28.Location = new System.Drawing.Point(821, 375);
            this.btn28.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn28.Name = "btn28";
            this.btn28.Size = new System.Drawing.Size(30, 27);
            this.btn28.TabIndex = 29;
            this.btn28.Text = "28";
            this.btn28.UseVisualStyleBackColor = true;
            this.btn28.Click += new System.EventHandler(this.btn28_Click);
            // 
            // btn41
            // 
            this.btn41.Location = new System.Drawing.Point(265, 413);
            this.btn41.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn41.Name = "btn41";
            this.btn41.Size = new System.Drawing.Size(30, 27);
            this.btn41.TabIndex = 30;
            this.btn41.Text = "41";
            this.btn41.UseVisualStyleBackColor = true;
            this.btn41.Click += new System.EventHandler(this.btn41_Click);
            // 
            // btn42
            // 
            this.btn42.Location = new System.Drawing.Point(231, 413);
            this.btn42.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn42.Name = "btn42";
            this.btn42.Size = new System.Drawing.Size(30, 27);
            this.btn42.TabIndex = 31;
            this.btn42.Text = "42";
            this.btn42.UseVisualStyleBackColor = true;
            this.btn42.Click += new System.EventHandler(this.btn42_Click);
            // 
            // btn43
            // 
            this.btn43.Location = new System.Drawing.Point(197, 413);
            this.btn43.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn43.Name = "btn43";
            this.btn43.Size = new System.Drawing.Size(30, 27);
            this.btn43.TabIndex = 32;
            this.btn43.Text = "43";
            this.btn43.UseVisualStyleBackColor = true;
            this.btn43.Click += new System.EventHandler(this.btn43_Click);
            // 
            // btn45
            // 
            this.btn45.Location = new System.Drawing.Point(129, 413);
            this.btn45.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn45.Name = "btn45";
            this.btn45.Size = new System.Drawing.Size(30, 27);
            this.btn45.TabIndex = 34;
            this.btn45.Text = "45";
            this.btn45.UseVisualStyleBackColor = true;
            this.btn45.Click += new System.EventHandler(this.btn45_Click);
            // 
            // btn46
            // 
            this.btn46.Location = new System.Drawing.Point(95, 413);
            this.btn46.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn46.Name = "btn46";
            this.btn46.Size = new System.Drawing.Size(30, 27);
            this.btn46.TabIndex = 35;
            this.btn46.Text = "46";
            this.btn46.UseVisualStyleBackColor = true;
            this.btn46.Click += new System.EventHandler(this.btn46_Click);
            // 
            // btn47
            // 
            this.btn47.Location = new System.Drawing.Point(61, 413);
            this.btn47.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn47.Name = "btn47";
            this.btn47.Size = new System.Drawing.Size(30, 27);
            this.btn47.TabIndex = 36;
            this.btn47.Text = "47";
            this.btn47.UseVisualStyleBackColor = true;
            this.btn47.Click += new System.EventHandler(this.btn47_Click);
            // 
            // btn48
            // 
            this.btn48.Location = new System.Drawing.Point(27, 413);
            this.btn48.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn48.Name = "btn48";
            this.btn48.Size = new System.Drawing.Size(30, 27);
            this.btn48.TabIndex = 37;
            this.btn48.Text = "48";
            this.btn48.UseVisualStyleBackColor = true;
            this.btn48.Click += new System.EventHandler(this.btn48_Click);
            // 
            // btn31
            // 
            this.btn31.Location = new System.Drawing.Point(583, 406);
            this.btn31.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn31.Name = "btn31";
            this.btn31.Size = new System.Drawing.Size(30, 27);
            this.btn31.TabIndex = 38;
            this.btn31.Text = "31";
            this.btn31.UseVisualStyleBackColor = true;
            this.btn31.Click += new System.EventHandler(this.btn31_Click);
            // 
            // btn32
            // 
            this.btn32.Location = new System.Drawing.Point(617, 406);
            this.btn32.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn32.Name = "btn32";
            this.btn32.Size = new System.Drawing.Size(30, 27);
            this.btn32.TabIndex = 39;
            this.btn32.Text = "32";
            this.btn32.UseVisualStyleBackColor = true;
            this.btn32.Click += new System.EventHandler(this.btn32_Click);
            // 
            // btn33
            // 
            this.btn33.Location = new System.Drawing.Point(651, 406);
            this.btn33.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn33.Name = "btn33";
            this.btn33.Size = new System.Drawing.Size(30, 27);
            this.btn33.TabIndex = 40;
            this.btn33.Text = "33";
            this.btn33.UseVisualStyleBackColor = true;
            this.btn33.Click += new System.EventHandler(this.btn33_Click);
            // 
            // btn34
            // 
            this.btn34.Location = new System.Drawing.Point(685, 406);
            this.btn34.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn34.Name = "btn34";
            this.btn34.Size = new System.Drawing.Size(30, 27);
            this.btn34.TabIndex = 41;
            this.btn34.Text = "34";
            this.btn34.UseVisualStyleBackColor = true;
            this.btn34.Click += new System.EventHandler(this.btn34_Click);
            // 
            // btn35
            // 
            this.btn35.Location = new System.Drawing.Point(719, 406);
            this.btn35.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn35.Name = "btn35";
            this.btn35.Size = new System.Drawing.Size(30, 27);
            this.btn35.TabIndex = 42;
            this.btn35.Text = "35";
            this.btn35.UseVisualStyleBackColor = true;
            this.btn35.Click += new System.EventHandler(this.btn35_Click);
            // 
            // btn38
            // 
            this.btn38.Location = new System.Drawing.Point(821, 406);
            this.btn38.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn38.Name = "btn38";
            this.btn38.Size = new System.Drawing.Size(30, 27);
            this.btn38.TabIndex = 43;
            this.btn38.Text = "38";
            this.btn38.UseVisualStyleBackColor = true;
            this.btn38.Click += new System.EventHandler(this.btn38_Click);
            // 
            // btn36
            // 
            this.btn36.Location = new System.Drawing.Point(753, 406);
            this.btn36.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn36.Name = "btn36";
            this.btn36.Size = new System.Drawing.Size(30, 27);
            this.btn36.TabIndex = 43;
            this.btn36.Text = "36";
            this.btn36.UseVisualStyleBackColor = true;
            this.btn36.Click += new System.EventHandler(this.btn36_Click);
            // 
            // btn37
            // 
            this.btn37.Location = new System.Drawing.Point(787, 406);
            this.btn37.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn37.Name = "btn37";
            this.btn37.Size = new System.Drawing.Size(30, 27);
            this.btn37.TabIndex = 44;
            this.btn37.Text = "37";
            this.btn37.UseVisualStyleBackColor = true;
            this.btn37.Click += new System.EventHandler(this.btn37_Click);
            // 
            // btn51
            // 
            this.btn51.Location = new System.Drawing.Point(265, 459);
            this.btn51.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn51.Name = "btn51";
            this.btn51.Size = new System.Drawing.Size(30, 27);
            this.btn51.TabIndex = 45;
            this.btn51.Text = "51";
            this.btn51.UseVisualStyleBackColor = true;
            this.btn51.Click += new System.EventHandler(this.btn51_Click);
            // 
            // btn52
            // 
            this.btn52.Location = new System.Drawing.Point(231, 459);
            this.btn52.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn52.Name = "btn52";
            this.btn52.Size = new System.Drawing.Size(30, 27);
            this.btn52.TabIndex = 46;
            this.btn52.Text = "52";
            this.btn52.UseVisualStyleBackColor = true;
            this.btn52.Click += new System.EventHandler(this.btn52_Click);
            // 
            // btn53
            // 
            this.btn53.Location = new System.Drawing.Point(197, 459);
            this.btn53.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn53.Name = "btn53";
            this.btn53.Size = new System.Drawing.Size(30, 27);
            this.btn53.TabIndex = 47;
            this.btn53.Text = "53";
            this.btn53.UseVisualStyleBackColor = true;
            this.btn53.Click += new System.EventHandler(this.btn53_Click);
            // 
            // btn54
            // 
            this.btn54.Location = new System.Drawing.Point(163, 459);
            this.btn54.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn54.Name = "btn54";
            this.btn54.Size = new System.Drawing.Size(30, 27);
            this.btn54.TabIndex = 48;
            this.btn54.Text = "54";
            this.btn54.UseVisualStyleBackColor = true;
            this.btn54.Click += new System.EventHandler(this.btn54_Click);
            // 
            // btn55
            // 
            this.btn55.Location = new System.Drawing.Point(129, 459);
            this.btn55.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn55.Name = "btn55";
            this.btn55.Size = new System.Drawing.Size(30, 27);
            this.btn55.TabIndex = 49;
            this.btn55.Text = "55";
            this.btn55.UseVisualStyleBackColor = true;
            this.btn55.Click += new System.EventHandler(this.btn55_Click);
            // 
            // btn81
            // 
            this.btn81.Location = new System.Drawing.Point(265, 490);
            this.btn81.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn81.Name = "btn81";
            this.btn81.Size = new System.Drawing.Size(30, 27);
            this.btn81.TabIndex = 50;
            this.btn81.Text = "81";
            this.btn81.UseVisualStyleBackColor = true;
            this.btn81.Click += new System.EventHandler(this.btn81_Click);
            // 
            // btn65
            // 
            this.btn65.Location = new System.Drawing.Point(719, 452);
            this.btn65.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn65.Name = "btn65";
            this.btn65.Size = new System.Drawing.Size(30, 27);
            this.btn65.TabIndex = 50;
            this.btn65.Text = "65";
            this.btn65.UseVisualStyleBackColor = true;
            this.btn65.Click += new System.EventHandler(this.btn65_Click);
            // 
            // btn61
            // 
            this.btn61.Location = new System.Drawing.Point(583, 452);
            this.btn61.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn61.Name = "btn61";
            this.btn61.Size = new System.Drawing.Size(30, 27);
            this.btn61.TabIndex = 51;
            this.btn61.Text = "61";
            this.btn61.UseVisualStyleBackColor = true;
            this.btn61.Click += new System.EventHandler(this.btn61_Click);
            // 
            // btn62
            // 
            this.btn62.Location = new System.Drawing.Point(617, 452);
            this.btn62.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn62.Name = "btn62";
            this.btn62.Size = new System.Drawing.Size(30, 27);
            this.btn62.TabIndex = 52;
            this.btn62.Text = "62";
            this.btn62.UseVisualStyleBackColor = true;
            this.btn62.Click += new System.EventHandler(this.btn62_Click);
            // 
            // btn64
            // 
            this.btn64.Location = new System.Drawing.Point(685, 452);
            this.btn64.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn64.Name = "btn64";
            this.btn64.Size = new System.Drawing.Size(30, 27);
            this.btn64.TabIndex = 53;
            this.btn64.Text = "64";
            this.btn64.UseVisualStyleBackColor = true;
            this.btn64.Click += new System.EventHandler(this.btn64_Click);
            // 
            // btn63
            // 
            this.btn63.Location = new System.Drawing.Point(651, 452);
            this.btn63.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn63.Name = "btn63";
            this.btn63.Size = new System.Drawing.Size(30, 27);
            this.btn63.TabIndex = 54;
            this.btn63.Text = "63";
            this.btn63.UseVisualStyleBackColor = true;
            this.btn63.Click += new System.EventHandler(this.btn63_Click);
            // 
            // btn84
            // 
            this.btn84.Location = new System.Drawing.Point(163, 490);
            this.btn84.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn84.Name = "btn84";
            this.btn84.Size = new System.Drawing.Size(30, 27);
            this.btn84.TabIndex = 55;
            this.btn84.Text = "84";
            this.btn84.UseVisualStyleBackColor = true;
            this.btn84.Click += new System.EventHandler(this.btn84_Click);
            // 
            // btn83
            // 
            this.btn83.Location = new System.Drawing.Point(197, 490);
            this.btn83.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn83.Name = "btn83";
            this.btn83.Size = new System.Drawing.Size(30, 27);
            this.btn83.TabIndex = 56;
            this.btn83.Text = "83";
            this.btn83.UseVisualStyleBackColor = true;
            this.btn83.Click += new System.EventHandler(this.btn83_Click);
            // 
            // btn82
            // 
            this.btn82.Location = new System.Drawing.Point(231, 490);
            this.btn82.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn82.Name = "btn82";
            this.btn82.Size = new System.Drawing.Size(30, 27);
            this.btn82.TabIndex = 57;
            this.btn82.Text = "82";
            this.btn82.UseVisualStyleBackColor = true;
            this.btn82.Click += new System.EventHandler(this.btn82_Click);
            // 
            // btn73
            // 
            this.btn73.Location = new System.Drawing.Point(651, 484);
            this.btn73.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn73.Name = "btn73";
            this.btn73.Size = new System.Drawing.Size(30, 27);
            this.btn73.TabIndex = 58;
            this.btn73.Text = "73";
            this.btn73.UseVisualStyleBackColor = true;
            this.btn73.Click += new System.EventHandler(this.btn73_Click);
            // 
            // btn72
            // 
            this.btn72.Location = new System.Drawing.Point(617, 484);
            this.btn72.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn72.Name = "btn72";
            this.btn72.Size = new System.Drawing.Size(30, 27);
            this.btn72.TabIndex = 59;
            this.btn72.Text = "72";
            this.btn72.UseVisualStyleBackColor = true;
            this.btn72.Click += new System.EventHandler(this.btn72_Click);
            // 
            // btn71
            // 
            this.btn71.Location = new System.Drawing.Point(583, 484);
            this.btn71.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn71.Name = "btn71";
            this.btn71.Size = new System.Drawing.Size(30, 27);
            this.btn71.TabIndex = 60;
            this.btn71.Text = "71";
            this.btn71.UseVisualStyleBackColor = true;
            this.btn71.Click += new System.EventHandler(this.btn71_Click);
            // 
            // btn85
            // 
            this.btn85.Location = new System.Drawing.Point(129, 490);
            this.btn85.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn85.Name = "btn85";
            this.btn85.Size = new System.Drawing.Size(30, 27);
            this.btn85.TabIndex = 61;
            this.btn85.Text = "85";
            this.btn85.UseVisualStyleBackColor = true;
            this.btn85.Click += new System.EventHandler(this.btn85_Click);
            // 
            // btn74
            // 
            this.btn74.Location = new System.Drawing.Point(685, 484);
            this.btn74.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn74.Name = "btn74";
            this.btn74.Size = new System.Drawing.Size(30, 27);
            this.btn74.TabIndex = 62;
            this.btn74.Text = "74";
            this.btn74.UseVisualStyleBackColor = true;
            this.btn74.Click += new System.EventHandler(this.btn74_Click);
            // 
            // btn75
            // 
            this.btn75.Location = new System.Drawing.Point(719, 484);
            this.btn75.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn75.Name = "btn75";
            this.btn75.Size = new System.Drawing.Size(30, 27);
            this.btn75.TabIndex = 63;
            this.btn75.Text = "75";
            this.btn75.UseVisualStyleBackColor = true;
            this.btn75.Click += new System.EventHandler(this.btn75_Click);
            // 
            // btnGrabar
            // 
            this.btnGrabar.Location = new System.Drawing.Point(163, 320);
            this.btnGrabar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(50, 24);
            this.btnGrabar.TabIndex = 64;
            this.btnGrabar.Text = "Grabar";
            this.btnGrabar.UseVisualStyleBackColor = true;
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // txtOdontograma
            // 
            this.txtOdontograma.Location = new System.Drawing.Point(124, 350);
            this.txtOdontograma.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtOdontograma.Name = "txtOdontograma";
            this.txtOdontograma.Size = new System.Drawing.Size(36, 20);
            this.txtOdontograma.TabIndex = 65;
            // 
            // groupBoxElemento
            // 
            this.groupBoxElemento.Controls.Add(this.txtDescripcion);
            this.groupBoxElemento.Controls.Add(this.label9);
            this.groupBoxElemento.Controls.Add(this.btnCancelar);
            this.groupBoxElemento.Controls.Add(this.btnGuardar);
            this.groupBoxElemento.Controls.Add(this.txtPrecio);
            this.groupBoxElemento.Controls.Add(this.cmbPrestacion);
            this.groupBoxElemento.Controls.Add(this.label7);
            this.groupBoxElemento.Controls.Add(this.label8);
            this.groupBoxElemento.Controls.Add(this.cmbCara);
            this.groupBoxElemento.Controls.Add(this.lblcara);
            this.groupBoxElemento.Controls.Add(this.txtNroElemento);
            this.groupBoxElemento.Controls.Add(this.lblElemento);
            this.groupBoxElemento.Location = new System.Drawing.Point(299, 350);
            this.groupBoxElemento.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBoxElemento.Name = "groupBoxElemento";
            this.groupBoxElemento.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBoxElemento.Size = new System.Drawing.Size(266, 187);
            this.groupBoxElemento.TabIndex = 77;
            this.groupBoxElemento.TabStop = false;
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(150, 132);
            this.txtDescripcion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(86, 20);
            this.txtDescripcion.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(41, 133);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 17);
            this.label9.TabIndex = 25;
            this.label9.Text = "Descripcion";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(159, 156);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(65, 27);
            this.btnCancelar.TabIndex = 24;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(50, 156);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(65, 27);
            this.btnGuardar.TabIndex = 23;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(150, 107);
            this.txtPrecio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(86, 20);
            this.txtPrecio.TabIndex = 22;
            // 
            // cmbPrestacion
            // 
            this.cmbPrestacion.FormattingEnabled = true;
            this.cmbPrestacion.Location = new System.Drawing.Point(150, 79);
            this.cmbPrestacion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbPrestacion.Name = "cmbPrestacion";
            this.cmbPrestacion.Size = new System.Drawing.Size(86, 21);
            this.cmbPrestacion.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(60, 108);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 20;
            this.label7.Text = "Precio";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(47, 81);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "Prestacion";
            // 
            // cmbCara
            // 
            this.cmbCara.FormattingEnabled = true;
            this.cmbCara.Location = new System.Drawing.Point(150, 51);
            this.cmbCara.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbCara.Name = "cmbCara";
            this.cmbCara.Size = new System.Drawing.Size(86, 21);
            this.cmbCara.TabIndex = 18;
            // 
            // lblcara
            // 
            this.lblcara.AutoSize = true;
            this.lblcara.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcara.Location = new System.Drawing.Point(63, 53);
            this.lblcara.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblcara.Name = "lblcara";
            this.lblcara.Size = new System.Drawing.Size(37, 17);
            this.lblcara.TabIndex = 17;
            this.lblcara.Text = "Cara";
            // 
            // txtNroElemento
            // 
            this.txtNroElemento.Location = new System.Drawing.Point(150, 25);
            this.txtNroElemento.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNroElemento.Name = "txtNroElemento";
            this.txtNroElemento.Size = new System.Drawing.Size(86, 20);
            this.txtNroElemento.TabIndex = 16;
            // 
            // lblElemento
            // 
            this.lblElemento.AutoSize = true;
            this.lblElemento.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElemento.Location = new System.Drawing.Point(31, 26);
            this.lblElemento.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblElemento.Name = "lblElemento";
            this.lblElemento.Size = new System.Drawing.Size(105, 17);
            this.lblElemento.TabIndex = 15;
            this.lblElemento.Text = "Pieza dental Nro";
            // 
            // btn44
            // 
            this.btn44.Location = new System.Drawing.Point(163, 413);
            this.btn44.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn44.Name = "btn44";
            this.btn44.Size = new System.Drawing.Size(30, 27);
            this.btn44.TabIndex = 33;
            this.btn44.Text = "44";
            this.btn44.UseVisualStyleBackColor = true;
            this.btn44.Click += new System.EventHandler(this.btn44_Click);
            // 
            // btnQuitar
            // 
            this.btnQuitar.Location = new System.Drawing.Point(217, 320);
            this.btnQuitar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnQuitar.Name = "btnQuitar";
            this.btnQuitar.Size = new System.Drawing.Size(50, 24);
            this.btnQuitar.TabIndex = 78;
            this.btnQuitar.Text = "Quitar";
            this.btnQuitar.UseVisualStyleBackColor = true;
            this.btnQuitar.Click += new System.EventHandler(this.btnQuitar_Click);
            // 
            // dgvHistorial
            // 
            this.dgvHistorial.AllowUserToAddRows = false;
            this.dgvHistorial.AllowUserToDeleteRows = false;
            this.dgvHistorial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistorial.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_fecha,
            this.col_idHistorial,
            this.col_idPrestacion,
            this.col_idelemento,
            this.col_idcara,
            this.colDescripcion,
            this.colimporte});
            this.dgvHistorial.Location = new System.Drawing.Point(163, 96);
            this.dgvHistorial.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvHistorial.Name = "dgvHistorial";
            this.dgvHistorial.ReadOnly = true;
            this.dgvHistorial.RowTemplate.Height = 28;
            this.dgvHistorial.Size = new System.Drawing.Size(577, 109);
            this.dgvHistorial.TabIndex = 79;
            // 
            // col_fecha
            // 
            this.col_fecha.HeaderText = "Fecha";
            this.col_fecha.Name = "col_fecha";
            this.col_fecha.ReadOnly = true;
            // 
            // col_idHistorial
            // 
            this.col_idHistorial.HeaderText = "Historial";
            this.col_idHistorial.Name = "col_idHistorial";
            this.col_idHistorial.ReadOnly = true;
            // 
            // col_idPrestacion
            // 
            this.col_idPrestacion.HeaderText = "Prestacion";
            this.col_idPrestacion.Name = "col_idPrestacion";
            this.col_idPrestacion.ReadOnly = true;
            // 
            // col_idelemento
            // 
            this.col_idelemento.HeaderText = "Elemento";
            this.col_idelemento.Name = "col_idelemento";
            this.col_idelemento.ReadOnly = true;
            // 
            // col_idcara
            // 
            this.col_idcara.HeaderText = "Cara";
            this.col_idcara.Name = "col_idcara";
            this.col_idcara.ReadOnly = true;
            // 
            // colDescripcion
            // 
            this.colDescripcion.HeaderText = "Descripcion";
            this.colDescripcion.Name = "colDescripcion";
            this.colDescripcion.ReadOnly = true;
            // 
            // colimporte
            // 
            this.colimporte.HeaderText = "Importe";
            this.colimporte.Name = "colimporte";
            this.colimporte.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 139);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "HISTORIAL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(92, 262);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 17);
            this.label10.TabIndex = 80;
            this.label10.Text = "NUEVO";
            // 
            // frmHistorialMedico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(865, 517);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvHistorial);
            this.Controls.Add(this.btnQuitar);
            this.Controls.Add(this.btn44);
            this.Controls.Add(this.groupBoxElemento);
            this.Controls.Add(this.txtOdontograma);
            this.Controls.Add(this.btnGrabar);
            this.Controls.Add(this.btn75);
            this.Controls.Add(this.btn74);
            this.Controls.Add(this.btn85);
            this.Controls.Add(this.btn71);
            this.Controls.Add(this.btn72);
            this.Controls.Add(this.btn73);
            this.Controls.Add(this.btn82);
            this.Controls.Add(this.btn83);
            this.Controls.Add(this.btn84);
            this.Controls.Add(this.btn63);
            this.Controls.Add(this.btn64);
            this.Controls.Add(this.btn62);
            this.Controls.Add(this.btn61);
            this.Controls.Add(this.btn65);
            this.Controls.Add(this.btn81);
            this.Controls.Add(this.btn55);
            this.Controls.Add(this.btn54);
            this.Controls.Add(this.btn53);
            this.Controls.Add(this.btn52);
            this.Controls.Add(this.btn51);
            this.Controls.Add(this.btn37);
            this.Controls.Add(this.btn36);
            this.Controls.Add(this.btn38);
            this.Controls.Add(this.btn35);
            this.Controls.Add(this.btn34);
            this.Controls.Add(this.btn33);
            this.Controls.Add(this.btn32);
            this.Controls.Add(this.btn31);
            this.Controls.Add(this.btn48);
            this.Controls.Add(this.btn47);
            this.Controls.Add(this.btn46);
            this.Controls.Add(this.btn45);
            this.Controls.Add(this.btn43);
            this.Controls.Add(this.btn42);
            this.Controls.Add(this.btn41);
            this.Controls.Add(this.btn28);
            this.Controls.Add(this.btn27);
            this.Controls.Add(this.btn26);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.btn24);
            this.Controls.Add(this.btn23);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.btn21);
            this.Controls.Add(this.btn18);
            this.Controls.Add(this.btn17);
            this.Controls.Add(this.btn16);
            this.Controls.Add(this.btn15);
            this.Controls.Add(this.btn14);
            this.Controls.Add(this.btn13);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dgvDetalle);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmHistorialMedico";
            this.Text = "frmHistorialMedico";
            this.Load += new System.EventHandler(this.frmHistorialMedico_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalle)).EndInit();
            this.groupBoxElemento.ResumeLayout(false);
            this.groupBoxElemento.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistorial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNombrePaciente;
        private System.Windows.Forms.TextBox txtOdontologo;
        private System.Windows.Forms.TextBox txtIdPaciente;
        private System.Windows.Forms.TextBox txtIdOdontologo;
        private System.Windows.Forms.Button btnBuscarOdontologos;
        private System.Windows.Forms.Button btnBuscarPacientes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.TextBox txtApellidoPaciente;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn17;
        private System.Windows.Forms.Button btn18;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn23;
        private System.Windows.Forms.Button btn24;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button btn26;
        private System.Windows.Forms.Button btn27;
        private System.Windows.Forms.Button btn28;
        private System.Windows.Forms.Button btn41;
        private System.Windows.Forms.Button btn42;
        private System.Windows.Forms.Button btn43;
        private System.Windows.Forms.Button btn45;
        private System.Windows.Forms.Button btn46;
        private System.Windows.Forms.Button btn47;
        private System.Windows.Forms.Button btn48;
        private System.Windows.Forms.Button btn31;
        private System.Windows.Forms.Button btn32;
        private System.Windows.Forms.Button btn33;
        private System.Windows.Forms.Button btn34;
        private System.Windows.Forms.Button btn35;
        private System.Windows.Forms.Button btn38;
        private System.Windows.Forms.Button btn36;
        private System.Windows.Forms.Button btn37;
        private System.Windows.Forms.Button btn51;
        private System.Windows.Forms.Button btn52;
        private System.Windows.Forms.Button btn53;
        private System.Windows.Forms.Button btn54;
        private System.Windows.Forms.Button btn55;
        private System.Windows.Forms.Button btn81;
        private System.Windows.Forms.Button btn65;
        private System.Windows.Forms.Button btn61;
        private System.Windows.Forms.Button btn62;
        private System.Windows.Forms.Button btn64;
        private System.Windows.Forms.Button btn63;
        private System.Windows.Forms.Button btn84;
        private System.Windows.Forms.Button btn83;
        private System.Windows.Forms.Button btn82;
        private System.Windows.Forms.Button btn73;
        private System.Windows.Forms.Button btn72;
        private System.Windows.Forms.Button btn71;
        private System.Windows.Forms.Button btn85;
        private System.Windows.Forms.Button btn74;
        private System.Windows.Forms.Button btn75;
        public System.Windows.Forms.DataGridView dgvDetalle;
        private System.Windows.Forms.Button btnGrabar;
        private System.Windows.Forms.TextBox txtOdontograma;
        private System.Windows.Forms.GroupBox groupBoxElemento;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.ComboBox cmbPrestacion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbCara;
        private System.Windows.Forms.Label lblcara;
        private System.Windows.Forms.TextBox txtNroElemento;
        private System.Windows.Forms.Label lblElemento;
        private System.Windows.Forms.DateTimePicker dtpfechaHistorial;
        private System.Windows.Forms.Button btn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id_elemento;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id_prestacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id_cara;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_importe;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id_historial;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_id_detalle;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnQuitar;
        private System.Windows.Forms.Button btnCargarPaciente;
        private System.Windows.Forms.Button btnCargarOdontologo;
        public System.Windows.Forms.DataGridView dgvHistorial;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_idHistorial;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_idPrestacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_idelemento;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_idcara;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDescripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn colimporte;
    }
}