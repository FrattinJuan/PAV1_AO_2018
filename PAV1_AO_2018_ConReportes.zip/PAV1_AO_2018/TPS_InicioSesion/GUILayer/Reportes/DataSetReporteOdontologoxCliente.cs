﻿namespace PAV1_AO_2018.GUILayer.Reportes
{


    partial class DataSetReporteOdontologoxCliente
    {
        partial class pacientesXodontologosDataTable
        {
        }
    }
}
