﻿namespace PAV1_AO_2018.GUILayer.Reportes
{


    partial class DSUsuariosXPerfil
    {
        partial class DataTable1DataTable
        {
        }
    }
}
