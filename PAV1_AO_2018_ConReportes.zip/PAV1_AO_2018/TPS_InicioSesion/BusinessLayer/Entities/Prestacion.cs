﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAV1_AO_2018.BusinessLayer
{
    public class Prestacion
    {
        public string nombre { get; set; }
        public string cod_prestacion { get; set; }

        public string descripcion { get; set; }

        public int id_prestacion { get; set; }


        
    }
}
