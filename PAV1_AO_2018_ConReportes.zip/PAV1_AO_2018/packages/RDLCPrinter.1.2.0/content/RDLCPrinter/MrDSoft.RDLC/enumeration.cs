﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DSoft
{
    public enum ReportType
    {
        Printer,
        Word,
        PDF,
        Excel,
        Image,
        //PlainText
    }
}
