﻿namespace RDLCDemo {
    
    
    public partial class NorthwindDataSet {
    }
}
